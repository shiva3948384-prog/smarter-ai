package com.example.domain.models

object AiModelCatalog {

    // Sensible defaults selected strictly from the 7 official Apinex models
    const val DEFAULT_MODEL_ID = "free/glm-5.3-flash"
    const val DEFAULT_CODING_MODEL_ID = "free/qwen-3.8-max"
    const val DEFAULT_REASONING_MODEL_ID = "free/deepseek-v4.1-flash"
    const val DEFAULT_VISION_MODEL_ID = "free/gemini-3.8-flash"

    /**
     * The exact 7 Apinex Bond API chat models in the required display order.
     * Model IDs are used verbatim in API requests without renaming or normalization.
     */
    val APINEX_CHAT_MODELS: List<AiModelDefinition> = listOf(
        AiModelDefinition(
            providerModelId = "free/muse-spark-1.3",
            displayName = "Muse Spark 1.3",
            provider = AiProvider.APINEX,
            category = ModelCategory.CREATIVE_WRITING,
            description = "Expressive creative writing, brainstorming, and natural multilingual conversations with 1M context.",
            capabilities = setOf(
                ModelCapability.STREAMING,
                ModelCapability.FAST_INFERENCE,
                ModelCapability.LONG_CONTEXT,
                ModelCapability.MULTILINGUAL
            ),
            supportsStreaming = true,
            supportsVision = false,
            isRecommended = true,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            contextWindowTokens = 1_000_000
        ),
        AiModelDefinition(
            providerModelId = "free/gemini-3.8-flash",
            displayName = "Gemini 3.8 Flash",
            provider = AiProvider.APINEX,
            category = ModelCategory.MULTIMODAL_VISION,
            description = "High-speed multimodal assistant for general chat, image understanding, coding, and 1M-token context.",
            capabilities = setOf(
                ModelCapability.STREAMING,
                ModelCapability.VISION,
                ModelCapability.FAST_INFERENCE,
                ModelCapability.CODE_GENERATION,
                ModelCapability.LONG_CONTEXT,
                ModelCapability.MULTILINGUAL
            ),
            supportsStreaming = true,
            supportsVision = true,
            isRecommended = true,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            contextWindowTokens = 1_000_000
        ),
        AiModelDefinition(
            providerModelId = "free/qwen-3.8-max",
            displayName = "Qwen 3.8 MAX",
            provider = AiProvider.APINEX,
            category = ModelCategory.CODING,
            description = "Flagship coding, software architecture, debugging, and technical reasoning model with 1M context.",
            capabilities = setOf(
                ModelCapability.STREAMING,
                ModelCapability.CODE_GENERATION,
                ModelCapability.REASONING,
                ModelCapability.LONG_CONTEXT,
                ModelCapability.MULTILINGUAL
            ),
            supportsStreaming = true,
            supportsVision = false,
            isRecommended = true,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            contextWindowTokens = 1_000_000
        ),
        AiModelDefinition(
            providerModelId = "free/kimi-k3",
            displayName = "Kimi K3",
            provider = AiProvider.APINEX,
            category = ModelCategory.GENERAL_CHAT,
            description = "Long-context conversational and analytical model for deep document comprehension and tool workflows.",
            capabilities = setOf(
                ModelCapability.STREAMING,
                ModelCapability.REASONING,
                ModelCapability.CODE_GENERATION,
                ModelCapability.LONG_CONTEXT,
                ModelCapability.MULTILINGUAL
            ),
            supportsStreaming = true,
            supportsVision = false,
            isRecommended = true,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            contextWindowTokens = 1_000_000
        ),
        AiModelDefinition(
            providerModelId = "free/deepseek-v4.1-flash",
            displayName = "Deepseek V4.1 Flash 1017",
            provider = AiProvider.APINEX,
            category = ModelCategory.REASONING,
            description = "Fast analytical reasoning, math, algorithm design, and step-by-step problem solving.",
            capabilities = setOf(
                ModelCapability.STREAMING,
                ModelCapability.REASONING,
                ModelCapability.CODE_GENERATION,
                ModelCapability.FAST_INFERENCE,
                ModelCapability.LONG_CONTEXT,
                ModelCapability.MULTILINGUAL
            ),
            supportsStreaming = true,
            supportsVision = false,
            isRecommended = true,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            contextWindowTokens = 1_000_000
        ),
        AiModelDefinition(
            providerModelId = "free/glm-5.3",
            displayName = "GLM 5.3",
            provider = AiProvider.APINEX,
            category = ModelCategory.CODING,
            description = "Full-scale GLM 5.3 model for complex engineering, multi-turn reasoning, and structured analysis.",
            capabilities = setOf(
                ModelCapability.STREAMING,
                ModelCapability.CODE_GENERATION,
                ModelCapability.REASONING,
                ModelCapability.LONG_CONTEXT,
                ModelCapability.MULTILINGUAL
            ),
            supportsStreaming = true,
            supportsVision = false,
            isRecommended = true,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            contextWindowTokens = 1_000_000
        ),
        AiModelDefinition(
            providerModelId = "free/glm-5.3-flash",
            displayName = "GLM-5.3 Flash",
            provider = AiProvider.APINEX,
            category = ModelCategory.GENERAL_CHAT,
            description = "Low-latency everyday assistant for fast chat, coding assistance, and Hindi/Hinglish/English dialogue.",
            capabilities = setOf(
                ModelCapability.STREAMING,
                ModelCapability.FAST_INFERENCE,
                ModelCapability.CODE_GENERATION,
                ModelCapability.LONG_CONTEXT,
                ModelCapability.MULTILINGUAL
            ),
            supportsStreaming = true,
            supportsVision = false,
            isRecommended = true,
            availabilityStatus = AvailabilityStatus.AVAILABLE,
            contextWindowTokens = 1_000_000
        )
    )

    /**
     * Active chat model catalog containing strictly the 7 Apinex models.
     */
    val INITIAL_DISCOVERY_MODELS: List<AiModelDefinition> = APINEX_CHAT_MODELS

    // ========================================================================
    // Pollinations Image Studio Models (Strictly for Image Generation Only)
    // ========================================================================
    val POLLINATIONS_FREE_IMAGE_MODELS: List<ImageModelSpec> = listOf(
        ImageModelSpec(
            modelId = "sana",
            displayName = "Smarter Flux Image",
            description = "Fast high-resolution diffusion model for crisp illustrations, concept art, and photorealistic scenes.",
            requiresApiKeyHeader = false
        ),
        ImageModelSpec(
            modelId = "flux",
            displayName = "Smarter Photoreal Studio",
            description = "High-detail photorealistic and artistic image synthesizer.",
            requiresApiKeyHeader = false
        ),
        ImageModelSpec(
            modelId = "community/scriptsnsenses-sys/flux-2-dev-free",
            displayName = "Smarter Concept Art",
            description = "Stylized digital artwork, architectural visualization, and creative compositions.",
            requiresApiKeyHeader = false
        )
    )

    // ========================================================================
    // Pollinations & On-Device Voice Profiles (Strictly for Audio Studio Only)
    // ========================================================================
    val POLLINATIONS_AUDIO_VOICES: List<SpeechVoiceSpec> = listOf(
        SpeechVoiceSpec("alloy", "Smarter Voice — Natural", "Balanced & Clear"),
        SpeechVoiceSpec("echo", "Smarter Voice — Warm", "Resonant & Calm"),
        SpeechVoiceSpec("fable", "Smarter Voice — Expressive", "Dynamic & Engaging"),
        SpeechVoiceSpec("onyx", "Smarter Voice — Deep", "Authoritative & Crisp"),
        SpeechVoiceSpec("nova", "Smarter Voice — Bright", "Energetic & Friendly"),
        SpeechVoiceSpec("shimmer", "Smarter Voice — Gentle", "Soft & Articulate")
    )

    fun isSupportedApinexModel(providerModelId: String): Boolean {
        if (providerModelId.isBlank()) return false
        return APINEX_CHAT_MODELS.any { it.providerModelId == providerModelId }
    }

    fun isVisionCapableModel(
        providerModelId: String,
        catalog: List<AiModelDefinition> = INITIAL_DISCOVERY_MODELS
    ): Boolean {
        if (providerModelId.isBlank()) return false
        val found = catalog.firstOrNull {
            it.providerModelId == providerModelId
        }
        return found?.supportsVision == true
    }

    fun findById(
        providerModelId: String,
        catalog: List<AiModelDefinition> = INITIAL_DISCOVERY_MODELS
    ): AiModelDefinition {
        if (providerModelId.isBlank()) {
            return catalog.firstOrNull { it.providerModelId == DEFAULT_MODEL_ID }
                ?: catalog.firstOrNull()
                ?: APINEX_CHAT_MODELS.last()
        }
        return catalog.firstOrNull {
            it.providerModelId == providerModelId
        } ?: AiModelDefinition(
            providerModelId = providerModelId,
            displayName = providerModelId,
            provider = AiProvider.APINEX,
            category = ModelCategory.GENERAL_CHAT,
            description = "Unrecognized or unavailable model.",
            capabilities = emptySet(),
            supportsStreaming = false,
            supportsVision = false,
            isRecommended = false,
            availabilityStatus = AvailabilityStatus.UNAVAILABLE,
            contextWindowTokens = null
        )
    }

    fun getDisplayName(
        providerModelId: String,
        catalog: List<AiModelDefinition> = INITIAL_DISCOVERY_MODELS
    ): String {
        return findById(providerModelId, catalog).displayName
    }

    fun mergeWithLiveProviderModels(
        baseCatalog: List<AiModelDefinition>,
        liveModelIds: Set<String>
    ): List<AiModelDefinition> {
        if (baseCatalog.isEmpty()) return emptyList()
        if (liveModelIds.isEmpty()) return baseCatalog

        return baseCatalog.map { model ->
            val isPresentInLive = liveModelIds.contains(model.providerModelId)
            val newStatus = if (isPresentInLive) {
                AvailabilityStatus.AVAILABLE
            } else {
                AvailabilityStatus.UNAVAILABLE
            }
            model.copy(availabilityStatus = newStatus)
        }
    }
}
