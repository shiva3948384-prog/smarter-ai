package com.example

import com.example.data.network.SupabaseAndGatewayClient
import com.example.data.network.SupabaseAndGatewayClient.Companion.ConversationLanguage
import com.example.domain.models.AiErrorType
import com.example.domain.models.AiModelCatalog
import com.example.domain.models.AiProvider
import com.example.domain.models.AvailabilityStatus
import com.example.domain.models.ChatMessage
import com.example.domain.models.Conversation
import com.example.domain.models.ConversationTimeGroup
import com.example.domain.models.MessageRole
import com.example.domain.models.MessageStatus
import com.example.domain.usecases.AuthValidationUseCase
import com.example.domain.usecases.ConversationGroupingUseCase
import com.example.ui.components.MarkdownBlock
import com.example.ui.components.MarkdownParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

class ExampleUnitTest {

    // ========================================================================
    // 1. Apinex Bond API Model Catalog & Media Studio Preservation Tests
    // ========================================================================

    @Test
    fun `model catalog contains exclusively the 7 Apinex Bond API chat models while preserving Pollinations for media studios`() {
        val chatModels = AiModelCatalog.INITIAL_DISCOVERY_MODELS
        assertEquals("Active chat model catalog must contain exactly 7 Apinex models", 7, chatModels.size)
        assertEquals(
            listOf(
                "free/muse-spark-1.3",
                "free/gemini-3.8-flash",
                "free/qwen-3.8-max",
                "free/kimi-k3",
                "free/deepseek-v4.1-flash",
                "free/glm-5.3",
                "free/glm-5.3-flash"
            ),
            chatModels.map { it.providerModelId }
        )
        assertEquals("free/glm-5.3-flash", AiModelCatalog.DEFAULT_MODEL_ID)
        assertEquals("free/qwen-3.8-max", AiModelCatalog.DEFAULT_CODING_MODEL_ID)
        assertEquals("free/deepseek-v4.1-flash", AiModelCatalog.DEFAULT_REASONING_MODEL_ID)
        assertEquals("free/gemini-3.8-flash", AiModelCatalog.DEFAULT_VISION_MODEL_ID)

        val unknownModel = AiModelCatalog.findById("unknown/model-id")
        assertEquals(AiProvider.APINEX, unknownModel.provider)
        assertEquals(AvailabilityStatus.UNAVAILABLE, unknownModel.availabilityStatus)

        // Verify Pollinations image and audio models are preserved intact for Media Studios
        val freeImageIds = AiModelCatalog.POLLINATIONS_FREE_IMAGE_MODELS.map { it.modelId }
        assertTrue(freeImageIds.contains("sana"))
        assertTrue(freeImageIds.contains("flux"))
        assertTrue(freeImageIds.contains("community/scriptsnsenses-sys/flux-2-dev-free"))
        assertEquals(6, AiModelCatalog.POLLINATIONS_AUDIO_VOICES.size)
    }

    @Test
    fun `mergeWithLiveProviderModels updates availability status for live Apinex models without adding extra models`() {
        val merged = AiModelCatalog.mergeWithLiveProviderModels(
            baseCatalog = AiModelCatalog.INITIAL_DISCOVERY_MODELS,
            liveModelIds = setOf("free/muse-spark-1.3", "free/glm-5.3-flash", "other/unlisted-model")
        )
        assertEquals(7, merged.size)
        assertEquals(AvailabilityStatus.AVAILABLE, merged.first { it.providerModelId == "free/muse-spark-1.3" }.availabilityStatus)
        assertEquals(AvailabilityStatus.AVAILABLE, merged.first { it.providerModelId == "free/glm-5.3-flash" }.availabilityStatus)
        assertEquals(AvailabilityStatus.UNAVAILABLE, merged.first { it.providerModelId == "free/kimi-k3" }.availabilityStatus)
    }

    // ========================================================================
    // 2. Authentication & Supabase Key Sanitization Validation Tests
    // ========================================================================

    @Test
    fun `sanitizeSupabaseAnonKey deduplicates doubled 416-char JWT key and strips Bearer prefix`() {
        val singleJwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3a2Z5YW11bGhGcHRneXdsdmVmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU3MTg5MDgsImV4cCI6MjA5MTI5NDkwOH0.sampleSignaturePart1234567890abcdef"
        val doubledJwt = singleJwt + singleJwt

        val cleanedFromDoubled = SupabaseAndGatewayClient.sanitizeSupabaseAnonKey(doubledJwt)
        assertEquals("Doubled JWT must be deduplicated into single 3-part JWT", singleJwt, cleanedFromDoubled)
        assertEquals(2, cleanedFromDoubled.count { it == '.' })

        val cleanedFromBearer = SupabaseAndGatewayClient.sanitizeSupabaseAnonKey("  \"Bearer $singleJwt\" ")
        assertEquals(singleJwt, cleanedFromBearer)
    }

    @Test
    fun `signup validation rejects weak passwords, mismatched confirmation, and invalid emails`() {
        val badEmail = AuthValidationUseCase.validateSignUp("not-an-email", "Password123", "Password123", "Alex")
        assertFalse(badEmail.isValid)

        val shortPass = AuthValidationUseCase.validateSignUp("user@example.com", "Ab1", "Ab1", "Alex")
        assertFalse(shortPass.isValid)

        val noDigits = AuthValidationUseCase.validateSignUp("user@example.com", "PasswordOnly", "PasswordOnly", "Alex")
        assertFalse(noDigits.isValid)

        val mismatch = AuthValidationUseCase.validateSignUp("user@example.com", "Password123", "Password999", "Alex")
        assertFalse(mismatch.isValid)

        val valid = AuthValidationUseCase.validateSignUp("user@example.com", "Password123", "Password123", "Alex")
        assertTrue(valid.isValid)
    }

    // ========================================================================
    // 3. Gateway Error Normalization Tests
    // ========================================================================

    @Test
    fun `mapHttpErrorToGatewayException normalizes rate limits, timeouts, invalid credentials, unsupported models, and context length`() {
        val rateLimit = SupabaseAndGatewayClient.mapHttpErrorToGatewayException(
            429,
            """{"code":"RATE_LIMITED","message":"Rate limit reached"}""",
            ""
        )
        assertEquals(AiErrorType.RATE_LIMITED, rateLimit.errorType)
        assertTrue(rateLimit.canRetry)

        val timeout = SupabaseAndGatewayClient.mapHttpErrorToGatewayException(
            504,
            """{"error":{"code":"NETWORK_TIMEOUT","message":"Service timed out"}}""",
            ""
        )
        assertEquals(AiErrorType.NETWORK_TIMEOUT, timeout.errorType)
        assertTrue(timeout.canRetry)

        val unsupported = SupabaseAndGatewayClient.mapHttpErrorToGatewayException(
            404,
            """{"error":{"message":"model_not_found"}}""",
            ""
        )
        assertEquals(AiErrorType.UNSUPPORTED_MODEL, unsupported.errorType)
        assertFalse(unsupported.canRetry)

        val invalidCreds = SupabaseAndGatewayClient.mapHttpErrorToGatewayException(
            401,
            """{"code":"INVALID_CREDENTIALS","message":"Invalid API key"}""",
            ""
        )
        assertEquals(AiErrorType.UNAUTHORIZED, invalidCreds.errorType)
        assertFalse(invalidCreds.canRetry)

        val contextError = SupabaseAndGatewayClient.mapHttpErrorToGatewayException(
            400,
            """{"code":"CONTEXT_LENGTH_EXCEEDED","message":"maximum context length exceeded"}""",
            ""
        )
        assertEquals(AiErrorType.CONTEXT_LENGTH_EXCEEDED, contextError.errorType)
        assertFalse(contextError.canRetry)
    }

    // ========================================================================
    // 4. Timezone-Aware Conversation Grouping Tests
    // ========================================================================

    @Test
    fun `groupByLocalTime buckets conversations into Today, Yesterday, Previous 7 Days, and Older`() {
        val tz = TimeZone.getTimeZone("America/Los_Angeles")
        val nowCal = Calendar.getInstance(tz).apply {
            set(2026, Calendar.OCTOBER, 29, 14, 30, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val nowMs = nowCal.timeInMillis
        val oneHourMs = 3_600_000L
        val oneDayMs = 24 * oneHourMs

        val conversations = listOf(
            Conversation("c_today", "u1", "Today Chat", "", nowMs - oneHourMs, nowMs - oneHourMs),
            Conversation("c_yesterday", "u1", "Yesterday Chat", "", nowMs - oneDayMs, nowMs - oneDayMs),
            Conversation("c_prev7", "u1", "3 Days Ago Chat", "", nowMs - 3 * oneDayMs, nowMs - 3 * oneDayMs),
            Conversation("c_older", "u1", "Last Month Chat", "", nowMs - 20 * oneDayMs, nowMs - 20 * oneDayMs)
        )

        val grouped = ConversationGroupingUseCase.groupByLocalTime(conversations, nowMs, tz)
        assertEquals(1, grouped[ConversationTimeGroup.TODAY]?.size)
        assertEquals(1, grouped[ConversationTimeGroup.YESTERDAY]?.size)
        assertEquals(1, grouped[ConversationTimeGroup.PREVIOUS_7_DAYS]?.size)
        assertEquals(1, grouped[ConversationTimeGroup.OLDER]?.size)
    }

    // ========================================================================
    // 5. Markdown Streaming Parser & <think> Stripping Tests
    // ========================================================================

    @Test
    fun `MarkdownParser handles incomplete fenced code blocks and stripThinkingBlocks removes internal reasoning tags`() {
        val partialStream = "# Heading\nHere is code:\n```kotlin\nfun main() {\n  println(\"Hi\")"
        val blocks = MarkdownParser.parseBlocks(partialStream)
        assertEquals(3, blocks.size)
        assertTrue(blocks[0] is MarkdownBlock.Heading)
        assertTrue(blocks[1] is MarkdownBlock.Paragraph)
        val codeBlock = blocks[2] as MarkdownBlock.CodeBlock
        assertEquals("kotlin", codeBlock.language)
        assertTrue("Incomplete code fence should be flagged as streaming", codeBlock.isIncompleteStream)

        val rawOutput = "<think>\nLet me analyze the NullPointerException in MainActivity.kt...\n</think>\nUse the safe call operator `?.` to prevent the crash."
        assertEquals(
            "Use the safe call operator `?.` to prevent the crash.",
            SupabaseAndGatewayClient.stripThinkingBlocks(rawOutput)
        )

        val inProgressOutput = "<think>\nStill thinking about the bug..."
        assertEquals("", SupabaseAndGatewayClient.stripThinkingBlocks(inProgressOutput))
    }

    // ========================================================================
    // 6. Security: APK Secret Exposure Check
    // ========================================================================

    @Test
    fun `BuildConfig strictly excludes server-side secrets`() {
        val fieldNames = BuildConfig::class.java.declaredFields.map { it.name }.toSet()
        val forbiddenSecrets = listOf(
            "APINEX_API_KEY",
            "APINEX_BASE_URL",
            "BREVO_API_KEY",
            "BREVO_SENDER_EMAIL",
            "POLLINATIONS_API_KEY",
            "SUPABASE_SERVICE_ROLE_KEY"
        )
        for (secret in forbiddenSecrets) {
            assertFalse(
                "$secret must NEVER be compiled into Android BuildConfig",
                fieldNames.contains(secret)
            )
        }
    }

    @Test
    fun `parseRetryAfterSeconds and normalizePollinationsFallbackModel handle HTTP 503 and 429 cooldowns and model IDs`() {
        assertEquals(38, SupabaseAndGatewayClient.parseRetryAfterSeconds("38", ""))
        assertEquals(45, SupabaseAndGatewayClient.parseRetryAfterSeconds(null, """{"retry_after": 45}"""))
        assertEquals(42, SupabaseAndGatewayClient.parseRetryAfterSeconds(null, "Free limit reached: wait 42 seconds"))
        assertEquals(null, SupabaseAndGatewayClient.parseRetryAfterSeconds(null, "Generic server error"))

        assertEquals("sana", SupabaseAndGatewayClient.normalizePollinationsFallbackModel("sana"))
        assertEquals("sana", SupabaseAndGatewayClient.normalizePollinationsFallbackModel("flux"))
        assertEquals("sana", SupabaseAndGatewayClient.normalizePollinationsFallbackModel("community/scriptsnsenses-sys/flux-2-dev-free"))
    }

    // ========================================================================
    // 7. Multilingual Detection (Hindi, Hinglish, English, Spanish, French) & Smarter AI Branding Tests
    // ========================================================================

    @Test
    fun `AiProvider displayName uses Smarter AI branding and never exposes Apinex in user-facing labels`() {
        assertEquals("Smarter AI", AiProvider.APINEX.displayName)
        AiModelCatalog.INITIAL_DISCOVERY_MODELS.forEach { model ->
            assertFalse("Model displayName must not contain Apinex", model.displayName.contains("Apinex", ignoreCase = true))
            assertFalse("Model description must not contain Apinex", model.description.contains("Apinex", ignoreCase = true))
            assertEquals("Smarter AI", model.provider.displayName)
        }
    }

    @Test
    fun `language detector accurately classifies Hindi Devanagari, Hinglish Roman, English, Spanish, French, and preserves language across follow-up messages`() {
        // Exact required test cases
        assertEquals(
            ConversationLanguage.HINDI_DEVANAGARI,
            SupabaseAndGatewayClient.detectMessageLanguagePreference("मुझे भारत के बारे में बताओ।")
        )
        assertEquals(
            ConversationLanguage.HINGLISH_ROMAN,
            SupabaseAndGatewayClient.detectMessageLanguagePreference("Bhai mujhe ek website banani hai.")
        )
        assertEquals(
            ConversationLanguage.ENGLISH,
            SupabaseAndGatewayClient.detectMessageLanguagePreference("Explain artificial intelligence.")
        )
        assertEquals(
            ConversationLanguage.SPANISH,
            SupabaseAndGatewayClient.detectMessageLanguagePreference("Explícame cómo funciona la inteligencia artificial.")
        )
        assertEquals(
            ConversationLanguage.FRENCH,
            SupabaseAndGatewayClient.detectMessageLanguagePreference("Explique-moi cette technologie.")
        )

        // Additional explicit & natural cases
        assertEquals(
            ConversationLanguage.HINDI_DEVANAGARI,
            SupabaseAndGatewayClient.detectMessageLanguagePreference("Explain binary search in Hindi")
        )
        assertEquals(
            ConversationLanguage.HINDI_DEVANAGARI,
            SupabaseAndGatewayClient.detectMessageLanguagePreference("मुझे Kotlin Coroutines के बारे में हिंदी में समझाओ")
        )

        assertEquals(
            ConversationLanguage.HINGLISH_ROMAN,
            SupabaseAndGatewayClient.detectMessageLanguagePreference("Please explain recursion in Hinglish")
        )
        assertEquals(
            ConversationLanguage.HINGLISH_ROMAN,
            SupabaseAndGatewayClient.detectMessageLanguagePreference("Bhai mujhe samjhao ki Jetpack Compose kaise kaam karta hai?")
        )

        assertEquals(
            ConversationLanguage.ENGLISH,
            SupabaseAndGatewayClient.detectMessageLanguagePreference("What is the difference between a process and a thread in Linux?")
        )

        val hindiConversation = listOf(
            ChatMessage("m1", "c1", "u1", MessageRole.USER, "मुझे recursion हिंदी में समझाओ", ""),
            ChatMessage("m2", "c1", "u1", MessageRole.ASSISTANT, "रिकर्शन (Recursion) एक ऐसी प्रक्रिया है जिसमें एक फ़ंक्शन खुद को कॉल करता है।", ""),
            ChatMessage("m3", "c1", "u1", MessageRole.USER, "Give 1 code example", "")
        )
        assertEquals(
            ConversationLanguage.HINDI_DEVANAGARI,
            SupabaseAndGatewayClient.resolveConversationLanguage(hindiConversation)
        )

        val hindiPrompt = SupabaseAndGatewayClient.buildSystemPromptForConversation(
            "",
            hindiConversation
        )
        assertTrue(hindiPrompt.contains("Devanagari"))
        assertTrue(hindiPrompt.contains("Do NOT translate programming keywords, code blocks, API names"))

        val spanishPrompt = SupabaseAndGatewayClient.buildSystemPromptForConversation(
            "",
            listOf(ChatMessage("m1", "c1", "u1", MessageRole.USER, "Explícame cómo funciona la inteligencia artificial.", ""))
        )
        assertTrue(spanishPrompt.contains("Spanish"))

        val frenchPrompt = SupabaseAndGatewayClient.buildSystemPromptForConversation(
            "",
            listOf(ChatMessage("m1", "c1", "u1", MessageRole.USER, "Explique-moi cette technologie.", ""))
        )
        assertTrue(frenchPrompt.contains("French"))

        val switchedToEnglish = hindiConversation + ChatMessage(
            "m4", "c1", "u1", MessageRole.USER, "Now please reply in English", ""
        )
        assertEquals(
            ConversationLanguage.ENGLISH,
            SupabaseAndGatewayClient.resolveConversationLanguage(switchedToEnglish)
        )
    }

    // ========================================================================
    // 8. History Trimming Tests
    // ========================================================================

    @Test
    fun `trimConversationHistory bounds context window and excludes error messages`() {
        val rawHistory = (1..16).map { idx ->
            ChatMessage(
                id = "m-$idx",
                conversationId = "c1",
                userId = "u1",
                role = if (idx % 2 == 1) MessageRole.USER else MessageRole.ASSISTANT,
                content = "Message number $idx",
                modelId = ""
            )
        } + ChatMessage(
            id = "m-err",
            conversationId = "c1",
            userId = "u1",
            role = MessageRole.ASSISTANT,
            content = "",
            modelId = "",
            status = MessageStatus.ERROR
        )

        val trimmed = SupabaseAndGatewayClient.trimConversationHistory(rawHistory, maxMessages = 10)
        assertEquals("History must be bounded to maxMessages (10)", 10, trimmed.size)
        assertFalse("Error messages must be excluded from upstream history", trimmed.any { it.status == MessageStatus.ERROR })
        assertEquals("m-7", trimmed.first().id)
        assertEquals("m-16", trimmed.last().id)
    }
}
